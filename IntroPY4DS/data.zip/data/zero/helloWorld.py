import platform

print('hello world {} '.format(platform.python_version()))