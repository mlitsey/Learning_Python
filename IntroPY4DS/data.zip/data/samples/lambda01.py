z = lambda x,y: x+y

print(z(4,5))
