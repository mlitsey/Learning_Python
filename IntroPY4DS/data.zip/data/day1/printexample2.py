x=41121
y=73123

if x<y:
    z=112
    print("x < y : y is {:>09} and x is {:<09}".format(x,y)) #true condition
else:
    print('line 4')    # false condition

z=z+8

print(f'the value for z is {z}')