x=42

s = 'hello world {}'.format(x)

print(s)

print('hello world %d from legacy code' % x)

print(f'hello world {x} from new python code')