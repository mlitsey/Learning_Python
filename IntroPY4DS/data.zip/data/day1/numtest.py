mydiv = 7/3

firstname='rafiq'.capitalize()
lastname='wayani'.upper()
print('python'.capitalize())
print(lastname)

print(mydiv)
print(type(mydiv))

