#filename:importexample.py
#location: c:\data\day1
#date: May 14th, 2018
#author: Rafiq Wayani
#purpose: provide example of the import statement
#usage: run code without any parameters

import platform

PythonVer = platform.python_version()
CustName='rafiq'

#print('this is python version {}'.format(PythonVer))
print(f'this is python version {PythonVer}')
print('hello in another line')