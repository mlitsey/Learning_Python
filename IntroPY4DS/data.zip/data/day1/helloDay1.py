mymessage=4>7
print(mymessage)
print(type(mymessage))
