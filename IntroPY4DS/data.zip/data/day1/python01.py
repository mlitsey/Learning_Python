
def main(): 
    message()
    
def message():
    print('hello world')
    
if __name__ == '__main__': main()

 