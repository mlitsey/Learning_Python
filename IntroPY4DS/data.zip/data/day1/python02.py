def main():
    message()
    
def message():
    print('hello world from message')
    print('line 2')
    print('this is a test')
    if True:         # this is a comment
        print('line 3')
    else:
        print('not true')   #this is also a comment... line ends

print('print this first')        

if __name__ == '__main__':main()
