x = 44
y = 43

if x != y:
    print("yes it's true")
else:
    print('no, not true')
    
print(id(x))
print(id(y))   