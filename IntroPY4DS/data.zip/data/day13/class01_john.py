class simpleCalc():    #defined a class called simpleCalc

    num1 = 0           #member variable (property) called num1
    num2 = 0           #member variable (property) called num2
    result = 0         #member variable (property) called result 
    def addNums(self): #method of the class called addNums
        self.result = self.num1 + self.num2    # adds the numbers together
        return (self.result)                   # returns the result value of the addition
    def subtractNums(self):
        
        self.result = self.num1 - self.num2
        return self.result
    
    def multiplyNums(self):
        self.result = self.num1 * self.num2
        return self.result
    
    def divideNums(self):
        self.result = self.num1 / self.num2
        return self.result

    def allResults(self):
        a, b = self.num1, self.num2
        s = f"""{a} + {b} = {self.addNums()}
{a} - {b} = {self.subtractNums()}
{a} * {b} = {self.multiplyNums()}
{a} / {b} = {self.divideNums()}"""
        print(s)

myCalc = simpleCalc()      # creates an instance of the simpleCalc class called myCalc
myCalc.num1 = 10           # assigns value to the property called num1
myCalc.num2 = 20           # assigns value to the property called num2
print(myCalc.addNums())    # calls the addNums method of the myCalc instance of the simpleCalc class

myCalc2 = simpleCalc()      # creates an instance of the simpleCalc class called myCalc
myCalc2.num1 = 50           # assigns value to the property called num1
myCalc2.num2 = 50           # assigns value to the property called num2
print(myCalc2.addNums())    # calls the addNums method of the myCalc instance of the simpleCalc class

myCalc2.num1 = 100
myCalc.num1 = 200
print(myCalc.allResults())
print(myCalc2.allResults())
