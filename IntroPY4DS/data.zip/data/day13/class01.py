class simpleCalc():    #defined a class called simpleCalc

    num1 = 0           #member variable (property) called num1
    num2 = 0           #member variable (property) called num2
    result = 0         #member variable (property) called result
    mathAction=0       #0 means add, 1 mean subtract, 2 mean mult, 3 mean div
    def addNums(self): #method of the class called addNums
        self.result = self.num1 + self.num2    # adds the numbers together
        return (self.result)                   # returns the result value of the addition
   
    def doMath(self):
        if self.mathAction==0:   # add
            return (self.num1 + self.num2)
        if self.mathAction==1:   # subtract
            return (self.num1 - self.num2)
        if self.mathAction==2:   # multiply
            return (self.num1 * self.num2)
        if self.mathAction==3:   # divide
            return (self.num1 / self.num2)

myNewCalc = simpleCalc()
myNewCalc.num1 = 10
myNewCalc.num2 = 20
myNewCalc.mathAction = 2   # multiply '2'

print(myNewCalc.doMath())

myCalc = simpleCalc()      # creates an instance of the simpleCalc class called myCalc
myCalc.num1 = 10           # assigns value to the property called num1
myCalc.num2 = 20           # assigns value to the property called num2
print(myCalc.addNums())    # calls the addNums method of the myCalc instance of the simpleCalc class

myCalc2 = simpleCalc()      # creates an instance of the simpleCalc class called myCalc
myCalc2.num1 = 50           # assigns value to the property called num1
myCalc2.num2 = 50           # assigns value to the property called num2
print(myCalc2.addNums())    # calls the addNums method of the myCalc instance of the simpleCalc class

myCalc2.num1 = 100
myCalc.num1 = 200
print(myCalc.addNums())    # calls the addNums method of the myCalc instance of the simpleCalc class
print(myCalc2.addNums())    # calls the addNums method of the myCalc instance of the simpleCalc class
