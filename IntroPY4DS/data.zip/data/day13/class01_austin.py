'''
01. add a subtract method
02. add a multiply method
03. add a divide method
04. add a single method that prints
    the resutls of the add, subtract
    dividing, or multiplecation
05. use each of the methods to show they work

bonus...
01. add a property that determins the action to perform.. add, multiple, divide
    or subtract
02. add a single method that uses the value of the 'action' property to 
    carry out the task.
'''

class simpleCalc():
    num1 = 0
    num2 = 0
    action = "add"
    result = 0

    def calc(self):
        # add
        if self.action == "add".lower():
            try:
                self.result = self.num1 + self.num2
                return self.result
            except:
                return "addition error"
        
        # subtract
        if self.action == "subtract".lower():
            try:
                self.result = self.num1 - self.num2
                return self.result
            except:
                return "subtraction error"
        
        # multiply
        if self.action == "multiply".lower():
            try:
                self.result = self.num1 * self.num2
                return self.result
            except:
                return "multiplication error"
        
        # divide
        if self.action == "divide".lower():
            try:
                self.result = self.num1 / self.num2
                return self.result
            except:
                return "division error"


def main():
    # create instance of simpleCalc
    calc = simpleCalc()
    
    # First add
    calc.num1 = 10
    calc.num2 = 20
    calc.action = "add"
    print(f"{calc.num1} + {calc.num2} = {calc.calc()}")

    # Then subtract
    calc.num1 = 100
    calc.num2 = 50
    calc.action = "subtract"
    print(f"{calc.num1} - {calc.num2} = {calc.calc()}")

    # Then multiply
    calc.num1 = 5
    calc.num2 = 5
    calc.action = "multiply"
    print(f"{calc.num1} * {calc.num2} = {calc.calc()}")

    # Then divide
    calc.num1 = 10
    calc.num2 = 5
    calc.action = "divide"
    print(f"{calc.num1} / {calc.num2} = {int(calc.calc())}")




# Main execution
main()

