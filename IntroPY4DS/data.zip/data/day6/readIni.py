import ConfigParser

def ReadINIFiles():
    config = configparser.ConfigParser()
    config.read("myconfig.ini")