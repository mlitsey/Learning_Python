def main():    # responsible for main procedure and logging result
    x = kitten(45)
    print(x)    # prints value returned by the kitten function 
    print(type(x))

def kitten(x):          # responsible for processing and returning value
    if x == 41:         # processed code number that means something
        return 'works'
    elif x==42:         # can also be an internal return code
        return 7.99
    elif x==43:         # can also be a system-wide error code
        return ('works best','for me','in a tuple')
    else:               # return this if none of the values are found
        return [41,42,43]
    
main()