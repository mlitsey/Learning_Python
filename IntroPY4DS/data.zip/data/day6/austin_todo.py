'''

Todo:
1. create a number generator
2. accepts 1, 2, or 3 parameters
    a. first parameter tells it number of items to count
    b. second parameter optionally tells it where to stop
    c. third parameter tells it stepping value

i.e. ...
counter(40) .. will count 1-40
counter(5,40) .. will count 5-40
counter(0,40,5) .. will count 0 to 40 in steps of 5

'''

def main():
    print("Austin's Number Generator"
          "-------------------------\n")
    # Ask for starting number (optional)
    argv1 = input("Enter starting number (default=0): ")
    if argv1 == '' or int(argv1) <= 0:
        argv1 = 0

    # Ask for ending number. This is required so
    # if the user doesn't enter anything then catch
    # and continue.
    while True:
        argv2 = input("Enter ending number: ")
        if argv2 == '':
            print("Ending value is required!")
            continue
        elif int(argv2) <= 0:
            print("Positive ending value is required.")
            continue
        elif int(argv2) <= int(argv1):
            print("Ending number must be greater than starting.")
            continue
        else:
            break
    
    # Finally last
    argv3 = input("Enter stepping (default=1): ")
    if argv3 == '' or int(argv3) <= 0:
        argv3 = 1

    # Now send on the args!
    number_generator(int(argv1), int(argv2), int(argv3))

def number_generator(*args):

    argc = len(args)

    start = args[0] # starting number
    end   = args[1] # ending number
    step  = args[2] # stepping

    numbers = []
    for i in range(start, end + 1, step):
        numbers.append(i)
        
    print(numbers)

main()