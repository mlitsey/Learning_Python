def writeData(passedData):
    filename=open('newfile.txt','w')        # creates a handle for the file
    filename.write(passedData)    # writes to the memory buffer
    filename.close()                      # saves the file on disk (location)
                                          # close will fail without permission
    
def main(passedData):
    writeData(passedData)
    
main('hello from me to you as a param')