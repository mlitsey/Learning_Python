def main():
    myargs=('meow','woof','brrrr')
    kitten(*myargs)

    
def kitten(*kwargs):      # kw=keyword args
    print(type(kwargs))
    if len(kwargs):        # if (true)
        for k in kwargs:   # this for statement will execute
            print(k)
main()
