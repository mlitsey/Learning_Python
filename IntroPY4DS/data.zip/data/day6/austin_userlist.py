'''
to do -
01. use the input command to allow users to enter values
    and when they press [enter] without typing any data
    end the list
02. store each value the user enters into a list
03. after they have ended their list, display everything
    they have entered
04. allow them to insert, remove, or append new values
i.e.    Enter username to store: rafiq
        Enter username to store: tom
        Enter username to store: billy
        Enter username to store: [enter]

        You entered: rafiq, tom, and billy

        Enter R = remove, I = insert, or A = append ... A
        Enter Username to Add: Eric
        Now the userlist is rafiq, tom, billy, and Eric
'''
from sys import exit

def main():
    username_list = []

    ######################
    # FIRST PHASE MENU
    ######################
    while True:
        input_name = input("Enter a username to store (blank if done): ")
        if input_name == '':
            # Check if list has anything. Make sure we have at least
            # one user before breaking loop
            if len(username_list):
                break
            else:
                # If we reached here then the user pressed enter before
                # sending any usernames
                print("Must have at least one user in the list!")
                continue
        else:
            username_list.append(input_name)
    
    # User broke out of loop. Print the values
    # of the user list.
    print("\nYou entered:", end=' ')
    # Print all but the last name
    for name in username_list[:-1]:
        print(name, end=', ')
    # Now append the last name .. using proper English.
    print("and {}.".format(username_list[-1]))


    ######################
    # SECOND PHASE MENU
    ######################
    # Choice gets reused like a *****
    while True:
        # Now we're asking if user wants to remove, insert, or append.
        print("\nEnter P=print list, R=remove, I=insert, A=append, or E=exit")
        # Get input; convert to lower.
        choice = input("Choice: ").lower()  

        # Because I don't know Python's version of getopt/switch..
        if choice  != 'p' \
        and choice != 'r' \
        and choice != 'i' \
        and choice != 'a' \
        and choice != 'e':
            print("{} is not a valid choice.".format(choice.upper()))
            continue
        
        # E - EXIT
        if choice == 'e'.lower():
            print("Bye!")
            exit()


        # P - PRINT
        if choice == 'p'.lower():
            # Make sure list isn't empty before accessing it...
            if len(username_list):
                print("\nUsername list is currently:")
                if len(username_list) > 1:
                    # Print all but the last name.
                    for name in username_list[:-1]:  print(name, end=', ')
                    # Now print the last name. Did it this way because
                    # if not then the last entry will be appended with
                    # a comma rather than a period.
                    print("and {}.".format(username_list[-1]))
                else:
                    # Just one entry is in the list, so just
                    # print that.
                    print(username_list[-1])
            else:
                print("\nUsername list is currently empty!")
            continue


        # R - REMOVE
        if choice == 'r'.lower():
            print("Enter the username that you wish to remove.")
            while True:
                choice = input("Username: ")
                if choice == '':
                    continue  # Repeat if null
                elif choice not in username_list:
                    print("User '{}' not found!".format(choice))
                    continue
                # Checks pass. Break.
                break
            # Remove user.
            print("Removing user '{}'.".format(choice))
            username_list.remove(choice)
            # Return to top of loop
            continue

        
        # I - INSERT
        if choice == 'i'.lower():
            while True:
                choice = input("Username: ")
                if choice == '':
                    continue  # Repeat if null
                else:
                    break
            print("Inserting {} to the beginning of the list.".format(choice))
            username_list.insert(0, choice)
            # Return to menu
            continue


        # A - Append
        if choice == 'a'.lower():
            while True:
                choice = input("Username: ")
                if choice == '':
                    continue  # Repeat if null
                else:
                    break
            print("Appending {} to the end of the list.".format(choice))
            username_list.append(choice)
            # Return to menu
            continue



# Begin execution
main()
