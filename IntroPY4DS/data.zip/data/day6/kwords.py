def main():
    myValue=[53]   # passing param by reference [passing a list]
    print('starting in the main function calling kitten')
    kitten(myValue)
    print(f'back in the main function')   # back from the called function
    print(f'value of {myValue} after returning from kitten') # displaying the changed value
    
def kitten(x):
    print(f'{x} hello from kitten') # displaying value before changing it
    x[0] = 45    # changing the value
    print(f'{x} after it has changed in kitten')  # returning to caller
    
main()