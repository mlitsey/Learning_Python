class buildUsers():
    userName=''
    userList=[]
    totusers=0
    def printUsers(self):
        if self.totusers != 0:
            if self.totusers == 1:
                print(f"there is only {self.totusers} user in the system and it's")
            else:
                print(f'there are {self.totusers} users in the system and they are')

            makeUserList=''
            atUser=0
            for user in self.userList:
                atUser+=1
                if atUser == (self.totusers) - 1:
                   makeUserList+=user + ', and '
                elif atUser != self.totusers:
                   makeUserList+=user + ', '
                else:
                    makeUserList+=user
            print(makeUserList)
        else:
            print('no users in system')
    
    def addUsers(self):
        self.totusers+=1
        self.userList.append(self.userName)
    
    def removeUsers(self):
        self.totusers-=1
        self.userList.remove(self.userName)
    
def askForUser():
    response = input("Enter Username to add to system:")
    return response

def askForChanges():
    response = input("A)ppend or R)emove Users:")
    return response


def main():
    makeUsers=buildUsers()
    validResponse=True
    while validResponse:
      getUserName=askForUser()
      if getUserName != '':
        makeUsers.userName=getUserName
        makeUsers.addUsers()
      else: validResponse=False
      
    makeUsers.printUsers()
    
main()