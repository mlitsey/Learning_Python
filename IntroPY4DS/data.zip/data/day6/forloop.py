def myLoop():
    classes = ('oracle','cisco','microsoft','iphone','android')
    
    for myclass in classes:
        if myclass == 'oracle':
          print('oracle in the house')
        print(myclass)         # printed all of the classes in the list


#    if classes[0]=='oracle':
#      print('yes, it is oracle')
#    else:
#        print('not oracle')
        
#    for myclass in range(4):    # creates a counter ... from 0-3 (total of 4)
        
#        print(classes[myclass]) # prints classes[0], classes[1], classes[2], classes[3]
        
def main():
    myLoop()
    
main()