def main():
    game = ['rock','paper','scissors','lizard','spock']
    x = game.pop()   # pop spock
    print(x)         # print spock... what was 'poped' and stored in x
    x = game.pop()   # pop lizard
    print(x)         # print lizard .. what was 'poped' and stored in x
#    game.remove('paper')
#    i = game.index('scissors')  # finds scissors in the game list
#    print(i)    # prints the index location (by number) of where it found scissors
#    print(game[i])  # prints scissors ... using the index location of where it found it
    game.insert(3,'computer')
    print_list(game)
    
def print_list(o):
    for i in o: print(i,end=' ')
    print()
    
main()