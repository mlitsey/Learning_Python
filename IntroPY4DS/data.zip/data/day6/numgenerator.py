def main():     # the main function definition
    for i in inclusive_range(2,40,3):    # pass with one, two, or three parameters
        print(i,end=' ')   # print the value that was 'yielded' in the inclusive_range func.
    print    # print a blank line at the end
    

def inclusive_range(*args):   # definition of the inclusive_range function that
    numargs=len(args)         # accepts *args tuple of values... determine # of values passed
    start=0                   # the counting will begin at 0 (to start with)
    step=1                    # the count will increment by 1 (to start with)
 
    # initialize parameters
    if numargs < 1:             # if no args are sent
        return 0                # return 0 to the caller (main) function 
    elif numargs == 1:          # if one args was sent
        stop = args[0]          # make the first args the stop value
                                # in this example it will stop at 25
    elif numargs == 2:          # if two args were sent
       (start,stop) = args      # start will be the first args,
                                # and stop will be the second args
    elif numargs == 3:          # if three args were sent
       (start,stop,step) = args # start,stop,step will be the three args values
    else: return 0              # more than 3 args were passed
    
    i = start                   # start counting at the start value passed in
    while i <= stop:            # stop counting at the stop value passed in 
        yield i                 # yield the next value (return the calling function)
        i += step               # increment by the step value (passed in) to increment by
    
        
main()    # call the main function 
    