import sqlite3

# create and connect to the "db"
myconn = sqlite3.connect('corp.db')

cursor = myconn.cursor()   # open the db for read/write

sql_commnand = """
create table employee (
    empid integer primary key,
    fname varchar(20),
    lname varchar(20)
); """

cursor.execute(sql_commnand)

sql_command = """
insert into employee values (null,'rafiq','wayani');
"""
cursor.execute(sql_command)
myconn.commit()  #save the insert
myconn.close() # close the db connection
