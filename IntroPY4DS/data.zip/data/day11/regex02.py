import re

#regex = r'([a-zA-Z]+) (\d+)'

#print(re.sub(regex,r'\2 of \1','June 24, August 9, December 25'))

regex = re.compile(r'(\w+) World')
print(regex.sub(r'\1 Earth','Hello World'))

#matches = re.finditer(regex,'June 24, August 9, Dec 12')

#for match in matches:
#    print(f'full match {(match.start())}')