import sys

save_err = sys.stderr

fh=open('errors.txt','w')

sys.stderr = fh

x = 10.0/0

# return to normal

sys.stderr = save_err

fh.close()
