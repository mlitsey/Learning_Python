import sqlite3

# create and connect to the "db"
myconn = sqlite3.connect('corp.db')

cursor = myconn.cursor()   # open the db for read/write

cursor.execute('select * from employee')

result = cursor.fetchall()
for r in result:
    print(r)
    
    