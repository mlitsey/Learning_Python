import sys


#for i in range(len(sys.argv)):
#    if i == 0:
#        print(f' function name called is {sys.argv[0]}')
#    else:
#        print(f' argument # {i} is {sys.argv[i]}' )


print('out via stdout')

sys.stdout.write('another way to do it\n')

x = input('read value using stdin: ')
print(x)


    
