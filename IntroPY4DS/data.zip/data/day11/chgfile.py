import sys

print('coming through stdout')   # printed on screen

save_stdout = sys.stdout

fh = open('original.txt','w')

sys.stdout = fh
print('this line will go to the file original.txt')   # printed to the file

#return to normal
sys.stdout = save_stdout

fh.close()


