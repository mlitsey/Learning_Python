import re

regex=r"([a-zA-Z]+) (\d+)"

if re.search(regex,"June 24"):
    
    match = re.search(regex,"June 24")
    
    print (f'Match at index {match.start()}, {match.end()}')
    
    print(f'full match {match.group(0)}')
    print(f'month {match.group(1)}')
    print(f'day {match.group(2)}')
    
    