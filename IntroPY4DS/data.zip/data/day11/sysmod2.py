import sys

while True:
    print('another iteration of std in and out')
    try:
        # read from sys.stdin
        number=input('enter a number:')
    except EOFError:
        print('\nall done\n')
        break
    else:
        number=int(number)
        if number==0:
            print('0 has a problem')
        else:
            print(f'{2.0 * number} is the {number} times 2 ')
            