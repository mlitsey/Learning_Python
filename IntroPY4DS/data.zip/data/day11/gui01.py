from tkinter import *

window = Tk()
window.title("Welcome to Python GUI Library")
lbl=Label(window,text="Hello World")
lbl.grid(column=0,row=0)

def clicked():
    lbl.configure(text='button clicked!')
    
btn = Button(window,text="Click this button",command=clicked)
btn.grid(column=1,row=0)
window.mainloop()

