x = 5
y = 3
z = x % y    # value of z is 5 % 3.. 2, value of z is 2 here at this line

z +=z # z = z + 2

print(f'result is {z}')

