hungry = -5

x = 'feed the bear now!' if hungry else 'do not feed the bear'
print(x)

