words = ['one','two','three','four','five']

n=0
while( n <= 4 ):
    print(words[n])
    n+=1
    
    