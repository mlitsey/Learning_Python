x = 0

print('x is {}'.format(x))

print(type(x))

if x:
    print('True')
else:
    print('False')
