import calendar

def calInfo(mm,yy):

  if yy>1949:  # the year passed in is at least 1950
    if mm<1 or mm>12:
        print('no such month')
        return
    else:
         print(calendar.month(yy,mm))
  else:
     print('too long ago!')
   
calInfo(2,1951)   