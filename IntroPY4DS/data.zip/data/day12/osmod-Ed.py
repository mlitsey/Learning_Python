import os

#print(f" parent directory {os.path.abspath('..')}")  # print the absolute path of the paren directory
#print(f' current directory {os.getcwd()}')  # current working directory

#print(os.listdir('.'))

try:
  filename=input('Enter the file name to open: ') # filename that we will read
  if filename != 'myfile.txt':
    print(f'{filename} is not myfile.txt')
  else:
    fh = open(filename,'r')    # opening the filename to be read and assigning it to fh
    text = fh.read()           # reading the contents of the file into a var called text
    print(text)                # printing the contents of the file
    fh.close()                 # closing the file
except FileNotFoundError:    # if the file was not found
  print(f'File [ {filename} ] was not found')     # display an error message