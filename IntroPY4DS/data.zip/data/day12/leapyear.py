
def isLeapYear(year):
  if (year % 4) == 0:  # is the year evenl divisible by 4
      return True    # return true to indicate leap year
  else:  # not a leap year if dividing by 4 leaves a remainder
      return False    # return false to indicate not a leap year
    
    
if isLeapYear(2004):   # the function call will return true if leap year
    print('leap year')
else:   # function call will return false if not a leap year
    print('not a leap year')


