
def main():
    seq = range(11)      # sequence numbers 0-10
    #seq2 = [x * 2 for x in seq]
    #seq2 = [x for x in seq if x % 3 == 0]
    #seq2 = [(x,x**2) for x in seq]
    #from math import pi
    #seq2 = [round(pi,i) for i in seq]
    #seq2 = {x:x**2 for x in seq}
    seq2 = {x for x in 'superduper' if x not in 'pd'}
    
    print_list(seq)      # prints this sequence
    print_list(seq2)      # prints this sequence
    
def print_list(o):       # accepts a param (happens to be a seq)
    for x in o: print(x,end=' ')    # prints the seq
    print()
    
main()