class buildUsers():
    userName=''
    userList=[]
    totUsers=0
    insertIndex = 0
    def printUsers(self):
        displayUsers=''
        if self.totUsers==0:
            print('no users to print')
        elif self.totUsers==1:
            displayUsers='1 user in the system and it is [ {}  ]'.format(self.userList[0])
            print(displayUsers)
        elif self.totUsers > 1:           # check to see if there are any users in the list
            print(f'{self.totUsers} users are in the system and they are')
            allUsers = self.userList     # all users in the list
            displayUsers = ''            # build my custom user display list from
            atUser = 0
            for currUser in allUsers:      # iterate through all users in the list
                atUser+=1                # increment the user count by 1
                if atUser == (self.totUsers) - 1:   # totalusers =3, and I'm at user 2
                     displayUsers+=currUser + ", and "
                elif atUser != (self.totUsers):     # not reached the end yet
                   displayUsers+=currUser + ', '
                else:
                    displayUsers+=currUser
            print(displayUsers)
                

        
    def addUsers(self):
        self.totUsers+=1   # increment the totUsers Count
        self.userList.append(self.userName)  # add the username to the userlist List
    
    def removeUsers(self):
        self.totUsers-=1   # reduce the totUsers count by 1
        self.userList.remove(self.userName)  # remove the user
        
    def insertUsers(self):
        if self.insertIndex <= (self.totUsers - 1):
          self.totUsers+=1  # increment the users since I will be inserting
          self.userList.insert(self.insertIndex,self.userName)
        else: print('cannot insert there!')


def askForUser():
    response = input("Enter Username to add to the system: ")
    return response
        
def main():
    makeUsers = buildUsers()
    getUserName=askForUser()
    makeUsers.userName=getUserName
    makeUsers.addUsers()
    while getUserName!='':
        getUserName=askForUser()
        if getUserName!='':
          makeUsers.userName=getUserName
          makeUsers.addUsers()

    makeUsers.printUsers()      # print the users before the insert
    makeUsers.insertIndex = 2   # insert at position 2
    makeUsers.userName='harry'  # specify harry to be inserted at position 2
    makeUsers.insertUsers()     # insert the user harry
    makeUsers.printUsers()      # print the userlist again
    
main()