class nameBuilder():
    fullName=''
    firstNames=[]
    lastNames=[]
    middleInits=[]
    totalNames=0
    
    def addNamesToList(self):
        splitFullName=self.fullName.split(' ')
        firstName=splitFullName[0]
        lastName=splitFullName[1]
        self.firstNames.append(firstName)
        self.lastNames.append(lastName)
        
def main():
    studentNames=nameBuilder()
    studentNames.fullName='john adams'
    studentNames.addNamesToList()
    studentNames.fullName='james madison'
    studentNames.addNamesToList()
    studentNames.fullName='abraham lincoln'
    studentNames.addNamesToList()
    
    for first in studentNames.firstNames:
        print(first)
    
    for last in studentNames.lastNames:
        print(last)
    

main()