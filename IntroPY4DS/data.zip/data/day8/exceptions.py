import sys

def main():
    try:
        x = 5/0
    except ValueError:
        print('value error, you do not know what you are doing!')
    except:
        print(f'unknown error: {sys.exc_info()}')
    else:
        print('good job!')
        print(x)
    
main()