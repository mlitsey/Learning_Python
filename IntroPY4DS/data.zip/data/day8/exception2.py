def myFunc(*args):    # function that accepts var length of parameters
    numargs = len(args)  # store the number of args passed in 
    start = 0
    stop = 1
    
    #init parameters
    if numargs < 1:
        raise TypeError(f'expected at least 1 argument and got {numargs}')
    elif numargs==1:
        print('all is well')
    elif numargs==2:
        print("all is well")
    elif numargs==3:
        raise TypeError(f'expected 1 or 2 args and got {numargs}')
    else: raise TypeError(f'too many arguments, only 2 at most and got {numargs}')
    
def main():
    try:
       myFunc(1,2,3) # pass no args first
    except TypeError as e:
        print(e)
    
main()