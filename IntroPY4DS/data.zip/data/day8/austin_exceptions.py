import sys

def main():
    # Get the first number
    while True:
        try:
            first_num = int(input("Enter first number: "))
        except ValueError:
            print("That's not a number!")
            continue
        except Exception as err:
            print(f"Something else happened: {err}")
            continue
        else:
            break
    
    # Get the second number
    while True:
        try:
            second_num = int(input("Enter second number: "))
        except ValueError:
            print("That's not a number!")
            continue
        except Exception as err:
            print(f"Something else happened: {err}")
            continue
        else:
            break

    print(f"Now I'm going to divide {first_num} by {second_num}!")

    dividend = 0    # declare before catching
    try:
        dividend = first_num / second_num
    except ZeroDivisionError:
        print("Dividing by zero is hazardous to my health.")
    except Exception as err:
        print(f"Some other error occurred.. {err}")

    print("Answer: {}".format(int(dividend)))

main()
