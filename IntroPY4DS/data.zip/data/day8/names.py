class nameBuilder():
    fullName=''   # will hold the full name
    firstNames=[] # list of first names
    lastNames=[]  #list of last names
    
    def addNamesToList(self):
        splitFullName=self.fullName.split(' ') # split full name
        firstName=splitFullName[0]  # store first name
        lastName=splitFullName[1]   # store last name
        self.firstNames.append(firstName) # add FN to list
        self.lastNames.append(lastName)   # add LN to list
    
    def printNames(self):  # print the names from the list
        for first in self.firstNames:  # loop FN
           print(f'first name from list is {first}') # print FN
    
        for last in self.lastNames:  # loop LN
           print(f'last name from list is {last}')  # print LN

           
def askForNames():   # ask for a name function
    response = input("Enter Name of A US President:")  
    return response  # return whatever the user entered
        
def main():  # main function
    usPresidents=nameBuilder()  # instance of nameBuilder class
    
    getUserName=''   # initialize getUserName with ''
    getUserName=askForNames() # store whatever the user entered
    
    totalPres=0  # creates a Pres count
    while (totalPres<8 and getUserName!=''):  # stay in loop until name is blank
       totalPres+=1 # add to pres count
       print(f'{totalPres} is the President Count')
       usPresidents.fullName=getUserName 
       usPresidents.addNamesToList()
       getUserName=askForNames()
       
    usPresidents.printNames()
    
    
main()
