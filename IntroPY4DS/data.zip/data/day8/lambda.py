import functools

def addNums(x,y):
    return x+y


def main():
   #z = addNums(7,9)
   #print(z)
   
   z = lambda x,y: x+y
   print(f'{z(12,12)}')
   nums = [10,90,30,40]
   calcAll=functools.reduce(lambda x,y: x+y,nums)
   print(f'{calcAll} is the sum of all numbers')
   
   maxVal = functools.reduce(lambda a,b:a if a>b else b,nums)
   print(maxVal)
   
   
main()