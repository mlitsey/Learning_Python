from enum import Enum

class Ops(Enum):
    ADD = 0
    SUB = 1
    MUL = 2
    DIV = 3
    EXP = 4

class simpleCalc():    #defined a class called simpleCalc

    num1 = 0           #member variable (property) called num1
    num2 = 0           #member variable (property) called num2
    result = 0         #member variable (property) called result
    action = Ops.ADD    #default to add
    _ops = {Ops.ADD: lambda a, b: a + b,
            Ops.SUB: lambda a, b: a - b,
            Ops.MUL: lambda a, b: a * b,
            Ops.DIV: lambda a, b: a / b,
            Ops.EXP: lambda a, b: a ** b
            }

    def act(self):
        operation = self._ops[self.action]
        return operation(self.num1, self.num2)
    
    def addNums(self):
        self.action = Ops.ADD
        return self.act()
    
    def subtractNums(self):
        self.action = Ops.SUB
        return self.act()        
    
    def multiplyNums(self):
        self.action = Ops.MUL
        return self.act()
    
    def divideNums(self):
        self.action = Ops.DIV
        return self.act()

    def expNums(self):
        self.action = Ops.EXP
        return self.act()
    
    def allResults(self):
        a, b = self.num1, self.num2
        s = f"""{a} + {b} = {self.addNums()}
{a} - {b} = {self.subtractNums()}
{a} * {b} = {self.multiplyNums()}
{a} / {b} = {self.divideNums()}
{a} **{b} = {self.expNums()}"""
        print(s)

myCalc = simpleCalc()

myCalc.num1, myCalc.action, myCalc.num2 = 10, Ops.MUL, 30
print(myCalc.act())

print(myCalc.allResults())

#myCalc2 = simpleCalc()
#myCalc2.num1 = 50           # assigns value to the property called num1
#myCalc2.num2 = 50           # assigns value to the property called num2
#print(myCalc2.allResults())
