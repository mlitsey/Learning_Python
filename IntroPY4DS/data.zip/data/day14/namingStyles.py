def printData(userName='NoName'):
    print(f"Hello to all Python People and Especially my dear friend, {userName} ")
    
def addNumbers(val1, val2):
    return (val1+val2)
    