from namingStyles import *

printData()

print(f' the sum of 3 and 4 is {addNumbers(3,4)}')


