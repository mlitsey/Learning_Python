from enum import Enum

class Ops(Enum):
    ADD = 0
    SUB = 1
    MUL = 2
    DIV = 3
    EXP = 4

class simpleCalc():    #defined a class called simpleCalc

    num1 = 0           #member variable (property) called num1
    num2 = 0           #member variable (property) called num2
    result = 0         #member variable (property) called result
    action = Ops.ADD    #default to add
    _ops = {Ops.ADD: lambda a, b: a + b,
            Ops.SUB: lambda a, b: a - b,
            Ops.MUL: lambda a, b: a * b,
            Ops.DIV: lambda a, b: a / b,
            Ops.EXP: lambda a, b: a ** b
            }

    def act(self):
        operation = self._ops[self.action]
        return operation(self.num1, self.num2)
    
    def addNums(self):
        self.action = Ops.ADD
        return self.act()
    
    def subtractNums(self):
        self.action = Ops.SUB
        return self.act()        
    
    def multiplyNums(self):
        self.action = Ops.MUL
        return self.act()
    
    def divideNums(self):
        self.action = Ops.DIV
        return self.act()

    def expNums(self):
        self.action = Ops.EXP
        return self.act()
    
    def allResults(self):
        a, b = self.num1, self.num2
        s = f"""{a} + {b} = {self.addNums()}
{a} - {b} = {self.subtractNums()}
{a} * {b} = {self.multiplyNums()}
{a} / {b} = {self.divideNums()}
{a} **{b} = {self.expNums()}"""
        print(s)

class CalcInstr:
    _commands = {"add": Ops.ADD,
                 "multiply": Ops.MUL,
                 "subtract": Ops.SUB,
                 "divide": Ops.DIV,
                 "exp": Ops.EXP
                 }
                 
    def unpack(text):
        """Note the lack of 'self' in this method.
            I'm using a class like a namespace; don't make instances
            of CalcInstr."""
        command, numstr1, numstr2 = text.split(',')
        return (CalcInstr._commands[command], float(numstr1), float(numstr2))

class CalcFile:
    """A class to read calc instruction files and save results files."""
    _strings = { Ops.ADD: "+",
             Ops.MUL: "*",
             Ops.SUB: "-",
             Ops.DIV: "/",
             Ops.EXP: "^"
             }
    def __init__(self, filename):
        """Open a file for processing calculator instructions"""
        self.results = []
        self.commands = []
        fileCalc = simpleCalc()
        #assuming the file format is valid.
        #This is a big, bad assumption.
        with open(filename, "r") as f:
            for line in f:
                if line.count(',') < 2: continue
                self.commands.append(CalcInstr.unpack(line))
        for c in self.commands:
            #this syntax splits the 3-tuple into different variables
            fileCalc.action, fileCalc.num1, fileCalc.num2 = c
            self.results.append(fileCalc.act())

    def save(self, filename):
        with open(filename, "w") as f:
            for i, c in enumerate(self.commands):
                command, num1, num2 = c
                opstring = self._strings[command]
                f.write("{} {} {} = {}\n".format(
                    num1, opstring, num2, self.results[i]))
        

if __name__ == '__main__':
    calcfile = CalcFile("input.txt")
    calcfile.save("output.txt")
