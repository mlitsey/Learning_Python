from class02_john_Ed import *

myCalc2 = simpleCalc()
myCalc2.num1 = 50           # assigns value to the property called num1
myCalc2.num2 = 50           # assigns value to the property called num2
print(myCalc2.allResults())