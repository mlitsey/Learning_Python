'''
01. allow for filename to be specified by user
02. allow usernames to be entered by user one username
    at a time
03. write all usernames to the file
'''
'''
fileHandle=open('myfile.txt','wt')

print('hello', file=fileHandle)
print('from', file=fileHandle)
print('earth', file=fileHandle)

fileHandle.close()
'''

def main():

    # Get filename
    while True:
        filename = input("Username filename: ")
        try:
            FILE = open(filename, 'wt')
            break
        except Exception as err:
            print(f"Could not create file at the specified path: {err}")
            continue

    # Get usernames
    userlist = [] # init list
    while True:
        username = input("Enter username to add (BLANK when done): ")
        if username == '':
            if len(userlist) < 1:
                print("Need at least one user!")
                continue
            else:
                break
        else:
            userlist.append(username)
    
    # Write usernames to file
    print("Writing usernames to file ")
    for user in userlist:
        # append comma if userlist is more than 2
        if len(userlist) > 1:
            print(user,end=', ',file=FILE)
        else:
            # just one user so no comma at the end
            print(user, file=FILE)
        print('.',end='',flush=True)
    print(' done')

    # Close file
    FILE.close()

main()
    
