fileHandle=open('myfile.txt','wt')  # open the file for writing

print('hello',file=fileHandle)  # write hello
print('from',file=fileHandle)   # write from
print('earth',file=fileHandle)  # write earth

fileHandle.close()              # close the file gracefully

