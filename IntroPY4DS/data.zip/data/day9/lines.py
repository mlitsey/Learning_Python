def main():
    fileHandle=open('origlines.txt')  # the file called lines.txt
    for line in fileHandle:
        print(line.rstrip())
        
def copyFile():
    inFile=open('origlines.txt','rt')
    outFile=open('newlines.txt','wt')
    for line in inFile:
        print(line.rstrip(),file=outFile)
        print('.',end='',flush=True)
    outFile.close()
    print('\ndone.')
        
        
#main()
copyFile()
    