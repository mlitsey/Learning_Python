s = "this is a long string with a bunch of words in it"
t = s.split()  # result was a list
print(type(t))
print(t)
s2 = ' -- '.join(t)
print(s2)