class customSplitter():
    strValue = ''   # that will hold the string that will need to be split/joined
    action = ''     # either J for Join or S for Split
    charValue =''     # either blank for S, or required for J
    
    def splitData(self):  # return a 0 if there is a problem or the split string
       if self.strValue!='':        # make sure that str is provided to be splitted
         if self.action == 'S':      # am I splitting
           if self.charValue=='':    # if charValue is blank
              splitStr = self.strValue.split()  # split the string
              return splitStr                   # return the split string
           else:   # if the char value is not blank specific char to split with
              splitStr = self.strValue.split(self.charValue) # split based on the charValue
              return splitStr  # return the result of the split
         if self.action!='J':   # not a join action           
            if self.charValue=='': # join without a char to join with is an error
                return '0'          # return error code 0 as a string
         else:                      # is a J
            splitStr = self.strValue.split() #split the string
            joinStr = self.charValue.join(splitStr) # join the string using the splitStr result
            return joinStr              # return the joined string
       else: return '0'             # no string provided to split (strValue == '')
       
def main():
    doSplit = customSplitter()
    doSplit.strValue='super duper string'
    doSplit.charValue='p'
    doSplit.action = 'S'
    retValue=doSplit.splitData()
    print(retValue)
    
        
main()    
    