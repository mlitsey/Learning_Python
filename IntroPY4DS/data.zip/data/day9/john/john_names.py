filename = "john_names.txt"

names = []
inp = None
#Input until blank line returned
while inp != '':
    if inp is not None:
        names.append(inp)
    print("Input a name (press Return to terminate):", end = ' ')
    inp = input()

#
# Challenge mode
#   Because you probably want to do something to the data, right?
#
#   1.) Correct capitalization of the names
#   2.) Format "John Adams" to "Adams, John" and "John F. Kennedy" to "Kennedy, John F."
#   3.) apply a number to the end of each line (order of input)
#   4.) Save the list alphabetized

#correct capitalization
names = [n.title() for n in names]

#Last name comma first name case
def lastCommaFirst(name):
    split = name.split()
    if len(split) > 1:
        namefinal = "{}, {}".format(split[-1], ' '.join(split[:-1]))
    else:
        namefinal = name
    return namefinal

names = map(lastCommaFirst, names)

#List comprehension to add numbers to end of each line
lines = ["{} (#{})".format(n, i+1) for i, n in enumerate(names)]

#alphabetize
lines.sort()

#save
with open(filename, "w") as f:
    for line in lines:
        f.write(line)
        f.write('\n')

#with block automatically closes file
