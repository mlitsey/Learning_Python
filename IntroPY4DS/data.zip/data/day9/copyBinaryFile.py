def main():
    inFile=open('pythonDemo.jpg','rb')
    outFile=open('newPythonDemo.jpg','wb')
    while True:
        buf=inFile.read(20240)
        if buf:
            outFile.write(buf)
            print('.',end='',flush=True)
        else: break
    outFile.close()
    print('\ndone.')
    
main()    