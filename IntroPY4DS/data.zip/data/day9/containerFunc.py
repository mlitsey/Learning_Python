#x = (1,2,3,4)
#y = ('one','two','three','four','five','six','seven')
#z = zip(x,y)

#for a,b in z: print(f'{a} - {b}')


#x = ('cat','dog','lion','cheetah','tiger')
#for i,v in enumerate(x): print(f'{i}: {v}')

x = -7.5
y = abs(x)

print(x)
print(y)
